﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class enstrumanstokkayit: Form
    {
        public enstrumanstokkayit()
        {
            InitializeComponent();
        }
        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\eneso\\OneDrive\\Masaüstü\\Enstruman otomasyonu\\EnstrumanStokTakip.accdb");

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void enstrumanstokkayit_Load(object sender, EventArgs e)
        {
            baglanti.Open();
            OleDbCommand komut = new OleDbCommand("select kategori from kategori", baglanti);
            OleDbDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                comboBox1.Items.Add(oku["kategori"].ToString());
            }
            baglanti.Close();

            baglanti.Open();
            OleDbCommand komut1 = new OleDbCommand("select enstrumanturu from enstrumanturu", baglanti);
            OleDbDataReader oku1 = komut1.ExecuteReader();
            while (oku1.Read())
            {
                comboBox2.Items.Add(oku1["enstrumanturu"].ToString());
            }
            baglanti.Close();

            baglanti.Open();
            OleDbCommand komut2 = new OleDbCommand("select enstrumanadı from enstrumanlar", baglanti);
            OleDbDataReader oku2 = komut2.ExecuteReader();
            while (oku2.Read())
            {
                comboBox3.Items.Add(oku2["enstrumanadı"].ToString());
            }
            baglanti.Close();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            //OleDbCommand komutenstrumanstok = new OleDbCommand("INSERT INTO enstrumanstok (barkodno, kategori, enstrumanturu,enstruman, rafno, adet, giristarihi) VALUES ('" + textBox1.Text + "','" + comboBox1.Text + "','" + comboBox2.Text + "','" + comboBox3.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + dateTimePicker1.Text + "')", baglanti);
            //komutenstrumanstok.ExecuteNonQuery();  // eski kodumuz hata aldık aşagıdaki gibi bir çözüm bulduk)
            OleDbCommand komutenstrumanstok = new OleDbCommand("INSERT INTO enstrumanstok (barkodno, kategori, enstrumanturu, enstruman, rafno, adet, giristarihi) VALUES (?, ?, ?, ?, ?, ?, ?)", baglanti);
            komutenstrumanstok.Parameters.AddWithValue("?", textBox1.Text);
            komutenstrumanstok.Parameters.AddWithValue("?", comboBox1.Text);
            komutenstrumanstok.Parameters.AddWithValue("?", comboBox2.Text);
            komutenstrumanstok.Parameters.AddWithValue("?", comboBox3.Text);
            komutenstrumanstok.Parameters.AddWithValue("?", textBox2.Text);
            komutenstrumanstok.Parameters.AddWithValue("?", textBox3.Text);
            komutenstrumanstok.Parameters.AddWithValue("?", DateTime.Parse(dateTimePicker1.Text));
            komutenstrumanstok.ExecuteNonQuery();
            label8.Text = "Kayıt Başarıyla Yapıldı";
            textBox1.Clear();   
            textBox2.Clear();
            textBox3.Clear();
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            comboBox3.Items.Clear();

            baglanti.Close();
            enstrumanstokkayit_Load(sender, e);
        }
    }
}
