﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class kullaniciekle: Form
    {
        public kullaniciekle()
        {
            InitializeComponent();
        }

        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\eneso\\OneDrive\\Masaüstü\\Enstruman otomasyonu\\EnstrumanStokTakip.accdb");

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            OleDbCommand kullanicieklekomutu = new OleDbCommand("insert into kullanıcıbilgi(ID,sifre,adsoyad,gorevi) values('" + textBox1.Text + "','" + textBox4.Text + "','" + textBox2.Text + "','" + textBox5.Text + "')", baglanti);
            kullanicieklekomutu.ExecuteNonQuery();
            baglanti.Close();
            label5.Text=textBox2.Text + " kullanıcısı eklendi ";
            textBox1.Clear();
            textBox2.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }
    }
}
