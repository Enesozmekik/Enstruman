﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class kategori: Form
    {
        public kategori()
        {
            InitializeComponent();
        }


        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\eneso\\OneDrive\\Masaüstü\\Enstruman otomasyonu\\EnstrumanStokTakip.accdb");


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            OleDbCommand kategorieklekomutu = new OleDbCommand("insert into kategori(ID,kategori) values('" + textBox1.Text + "','" + textBox2.Text + "') ",baglanti);
            kategorieklekomutu.ExecuteNonQuery();
            baglanti.Close();
            label3.Text = textBox2.Text + " kategorisi eklendi \n";
            textBox1.Clear();
            textBox2.Clear();
            
            this.Close();

        }
    }
}
