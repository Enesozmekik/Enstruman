﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class enstrumanstoksil: Form
    {
        public enstrumanstoksil()
        {
            InitializeComponent();
        }
        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\eneso\\OneDrive\\Masaüstü\\Enstruman otomasyonu\\EnstrumanStokTakip.accdb");

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            OleDbCommand silmekomutu = new OleDbCommand("delete from enstrumanstok where barkodno='" + textBox1.Text + "'", baglanti);
            silmekomutu.ExecuteNonQuery();
            baglanti.Close();
            label4.Text = textBox1.Text+" Barkod nolu enstrüman stoktan silindi";
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void enstrumanstoksil_Load(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            baglanti.Open();
            OleDbCommand komut = new OleDbCommand("select * from enstrumanstok where barkodno= '" + textBox1.Text + "'", baglanti);
            OleDbDataReader oku = komut.ExecuteReader();
            while (oku.Read())
            {
                textBox2.Text = oku["enstruman"].ToString();
                textBox3.Text = oku["adet"].ToString();
            }
            baglanti.Close();
        }
    }
}
