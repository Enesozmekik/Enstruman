﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class anamenu_: Form
    {
        public anamenu_()
        {
            InitializeComponent();
        }


        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void çıkışYapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void kategoriEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form kategoriekle = new kategori();
            kategoriekle.Show();
           // this.Hide();
        }

        private void enstrumanEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form enstrumanekle = new enstrumanekle();
            enstrumanekle.Show();



        }

        private void enstrumanEkleToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void enstrumanTuruEkleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form enstrumantur = new enstrumanturu();
            enstrumantur.Show();

        }

        private void enstrumanTuruEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void kullanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form kullanici = new kullaniciekle();
            kullanici.Show();
        }

        private void enstrumanEkleToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Form enstruman = new enstrumanekle();
            enstruman.Show();
        }

      

        private void enstrumanStokKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form kayit = new enstrumanstokkayit();
            kayit.Show();
        }

        private void enstrumanStokDuzenleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form duzenle = new enstrumanstokduzenle();
            duzenle.Show();
        }

        private void enstrumanStokSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form sil = new enstrumanstoksil();
            sil.Show();
        }

        private void yardımToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form yard = new yardim();
            yard.Show();
        }
    }
}
