﻿namespace WindowsFormsApp1
{
    partial class anamenu_
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.stokİslemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enstrumanStokKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enstrumanStokDuzenleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enstrumanStokSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eklemeİslemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kategoriEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kullanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enstrumanTuruEkleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.enstrumanEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çıkışYapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yardımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stokİslemleriToolStripMenuItem,
            this.eklemeİslemleriToolStripMenuItem,
            this.yardımToolStripMenuItem,
            this.çıkışYapToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // stokİslemleriToolStripMenuItem
            // 
            this.stokİslemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enstrumanStokKayıtToolStripMenuItem,
            this.enstrumanStokDuzenleToolStripMenuItem,
            this.enstrumanStokSilToolStripMenuItem});
            this.stokİslemleriToolStripMenuItem.Name = "stokİslemleriToolStripMenuItem";
            this.stokİslemleriToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.stokİslemleriToolStripMenuItem.Text = "Stok İslemleri";
            // 
            // enstrumanStokKayıtToolStripMenuItem
            // 
            this.enstrumanStokKayıtToolStripMenuItem.Name = "enstrumanStokKayıtToolStripMenuItem";
            this.enstrumanStokKayıtToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.enstrumanStokKayıtToolStripMenuItem.Text = "Enstruman Stok Kayıt";
            this.enstrumanStokKayıtToolStripMenuItem.Click += new System.EventHandler(this.enstrumanStokKayıtToolStripMenuItem_Click);
            // 
            // enstrumanStokDuzenleToolStripMenuItem
            // 
            this.enstrumanStokDuzenleToolStripMenuItem.Name = "enstrumanStokDuzenleToolStripMenuItem";
            this.enstrumanStokDuzenleToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.enstrumanStokDuzenleToolStripMenuItem.Text = "Enstruman Stok Duzenle";
            this.enstrumanStokDuzenleToolStripMenuItem.Click += new System.EventHandler(this.enstrumanStokDuzenleToolStripMenuItem_Click);
            // 
            // enstrumanStokSilToolStripMenuItem
            // 
            this.enstrumanStokSilToolStripMenuItem.Name = "enstrumanStokSilToolStripMenuItem";
            this.enstrumanStokSilToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.enstrumanStokSilToolStripMenuItem.Text = "Enstruman Stok Sil";
            this.enstrumanStokSilToolStripMenuItem.Click += new System.EventHandler(this.enstrumanStokSilToolStripMenuItem_Click);
            // 
            // eklemeİslemleriToolStripMenuItem
            // 
            this.eklemeİslemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kategoriEkleToolStripMenuItem,
            this.kullanToolStripMenuItem,
            this.enstrumanTuruEkleToolStripMenuItem1,
            this.enstrumanEkleToolStripMenuItem});
            this.eklemeİslemleriToolStripMenuItem.Name = "eklemeİslemleriToolStripMenuItem";
            this.eklemeİslemleriToolStripMenuItem.Size = new System.Drawing.Size(104, 20);
            this.eklemeİslemleriToolStripMenuItem.Text = "Ekleme İslemleri";
            // 
            // kategoriEkleToolStripMenuItem
            // 
            this.kategoriEkleToolStripMenuItem.Name = "kategoriEkleToolStripMenuItem";
            this.kategoriEkleToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.kategoriEkleToolStripMenuItem.Text = "Kategori Ekle";
            this.kategoriEkleToolStripMenuItem.Click += new System.EventHandler(this.kategoriEkleToolStripMenuItem_Click);
            // 
            // kullanToolStripMenuItem
            // 
            this.kullanToolStripMenuItem.Name = "kullanToolStripMenuItem";
            this.kullanToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.kullanToolStripMenuItem.Text = "Kullanıcı Ekle";
            this.kullanToolStripMenuItem.Click += new System.EventHandler(this.kullanToolStripMenuItem_Click);
            // 
            // enstrumanTuruEkleToolStripMenuItem1
            // 
            this.enstrumanTuruEkleToolStripMenuItem1.Name = "enstrumanTuruEkleToolStripMenuItem1";
            this.enstrumanTuruEkleToolStripMenuItem1.Size = new System.Drawing.Size(183, 22);
            this.enstrumanTuruEkleToolStripMenuItem1.Text = "Enstruman Turu ekle";
            this.enstrumanTuruEkleToolStripMenuItem1.Click += new System.EventHandler(this.enstrumanTuruEkleToolStripMenuItem1_Click);
            // 
            // enstrumanEkleToolStripMenuItem
            // 
            this.enstrumanEkleToolStripMenuItem.Name = "enstrumanEkleToolStripMenuItem";
            this.enstrumanEkleToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.enstrumanEkleToolStripMenuItem.Text = "Enstruman Ekle";
            this.enstrumanEkleToolStripMenuItem.Click += new System.EventHandler(this.enstrumanEkleToolStripMenuItem_Click_1);
            // 
            // çıkışYapToolStripMenuItem
            // 
            this.çıkışYapToolStripMenuItem.Name = "çıkışYapToolStripMenuItem";
            this.çıkışYapToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.çıkışYapToolStripMenuItem.Text = "Çıkış Yap";
            this.çıkışYapToolStripMenuItem.Click += new System.EventHandler(this.çıkışYapToolStripMenuItem_Click);
            // 
            // yardımToolStripMenuItem
            // 
            this.yardımToolStripMenuItem.Name = "yardımToolStripMenuItem";
            this.yardımToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.yardımToolStripMenuItem.Text = "Yardım";
            this.yardımToolStripMenuItem.Click += new System.EventHandler(this.yardımToolStripMenuItem_Click);
            // 
            // anamenu_
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "anamenu_";
            this.Text = "anamenu_";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem stokİslemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enstrumanStokKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enstrumanStokDuzenleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enstrumanStokSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eklemeİslemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kategoriEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kullanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çıkışYapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enstrumanTuruEkleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem enstrumanEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yardımToolStripMenuItem;
    }
}