﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\eneso\\OneDrive\\Masaüstü\\Enstruman otomasyonu\\EnstrumanStokTakip.accdb");


        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "") {
                MessageBox.Show("Lütfen Gerekli Alanları Doldurunuz\n");
            }
            else
            {
                baglanti.Open();
                OleDbCommand komut = new OleDbCommand("select * from kullanıcıbilgi where ID =  '" + textBox1.Text + "' ", baglanti);
                OleDbDataReader okuyucu = komut.ExecuteReader();
                if (okuyucu.Read() == true) {
                    if (textBox1.Text == okuyucu["ID"].ToString() && textBox2.Text == okuyucu["sifre"].ToString()) {
                        MessageBox.Show("Hosgeldiniz Sayin :" + okuyucu["adsoyad"].ToString());
                        Form anamenu = new anamenu_();
                        anamenu.Show();
                        this.Hide();
                        
                    }
                    else
                    {
                        MessageBox.Show("Hatali Giris!\n Bilgileriniz Kontrol Edin \n");

                    }
                }
                else
                {
                    MessageBox.Show("Hatali Giris!\n Bilgileriniz Kontrol Edin \n");
                }
                baglanti.Close();

            }

        } 
    }
}
    
