﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class enstrumanstokduzenle: Form
    {
        public enstrumanstokduzenle()
        {
            InitializeComponent();
        }
        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\eneso\\OneDrive\\Masaüstü\\Enstruman otomasyonu\\EnstrumanStokTakip.accdb");

        private void button1_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            OleDbCommand guncellekomut = new OleDbCommand("update enstrumanstok set barkodno='" + int.Parse(textBox1.Text) + "',kategori='" + comboBox1.Text + "',enstrumanturu='" + comboBox2.Text + "',enstruman='" + comboBox3.Text + "',rafno='" + textBox2.Text + "',adet='" + textBox3.Text + "',giristarihi='" + dateTimePicker1.Text + "' where barkodno='" + textBox1.Text + "'", baglanti);
            guncellekomut.ExecuteNonQuery();
            baglanti.Close();
            label8.Text = textBox1.Text+"barkodnolu ürün güncelleme işlemi başarılı.";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            baglanti.Open();
            OleDbCommand komut = new OleDbCommand("select * from enstrumanstok where barkodno='" + textBox1.Text + "'", baglanti);
            OleDbDataReader oku = komut.ExecuteReader();
            while(oku.Read())
            {
                comboBox1.Text = oku["kategori"].ToString();
                comboBox2.Text = oku["enstrumanturu"].ToString();
                comboBox3.Text = oku["enstruman"].ToString();
                textBox2.Text = oku["rafno"].ToString();
                textBox3.Text = oku["adet"].ToString();
                dateTimePicker1.Text = oku["giristarihi"].ToString();
            }
            baglanti.Close();
        }

        private void enstrumanstokduzenle_Load(object sender, EventArgs e)
        {

        }
    }
}
